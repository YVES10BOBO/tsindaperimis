import 'package:flutter/material.dart';

import '../core/app_colors.dart';
import '../data/models.dart';

/// Ishushanya ibimenyetso by'umuhanda hakoreshejwe code (nta mafoto akenewe).
/// Nyuma ushobora kubisimbuza amafoto nyayo (assets) y'ibimenyetso byemewe.
class RoadSign extends StatelessWidget {
  const RoadSign({super.key, required this.type, this.size = 96, this.label});

  final SignType type;
  final double size;
  final String? label;

  static const List<Offset> _octagon = <Offset>[
    Offset(0.3, 0), Offset(0.7, 0), Offset(1, 0.3), Offset(1, 0.7),
    Offset(0.7, 1), Offset(0.3, 1), Offset(0, 0.7), Offset(0, 0.3),
  ];
  static const List<Offset> _triangleUp = <Offset>[
    Offset(0.5, 0.05), Offset(0.96, 0.9), Offset(0.04, 0.9),
  ];
  static const List<Offset> _triangleDown = <Offset>[
    Offset(0.04, 0.1), Offset(0.96, 0.1), Offset(0.5, 0.95),
  ];

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Ikimenyetso cy\'umuhanda',
      child: SizedBox(width: size, height: size, child: _buildSign()),
    );
  }

  Widget _buildSign() {
    switch (type) {
      case SignType.stop:
        return CustomPaint(
          painter: _PolyPainter(_octagon, AppColors.signRed, Colors.white, size * 0.04),
          child: Center(
            child: Text('STOP',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: size * 0.24,
                    letterSpacing: 1)),
          ),
        );
      case SignType.giveWay:
        return CustomPaint(
          painter: _PolyPainter(_triangleDown, Colors.white, AppColors.signRed, size * 0.09),
        );
      case SignType.noEntry:
        return _circle(
          fill: AppColors.signRed,
          child: Container(
            width: size * 0.62,
            height: size * 0.16,
            color: Colors.white,
          ),
        );
      case SignType.speedLimit:
        return _prohibitory(
          Text(label ?? '40',
              style: TextStyle(
                  color: AppColors.signBlack,
                  fontWeight: FontWeight.w900,
                  fontSize: size * 0.34)),
        );
      case SignType.noOvertaking:
        return _prohibitory(
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(Icons.directions_car, color: AppColors.signRed, size: size * 0.3),
              Icon(Icons.directions_car, color: AppColors.signBlack, size: size * 0.3),
            ],
          ),
        );
      case SignType.noParking:
        return Stack(
          children: <Widget>[
            _circle(fill: AppColors.signBlue, border: AppColors.signRed),
            CustomPaint(
              size: Size(size, size),
              painter: _SlashPainter(AppColors.signRed, size * 0.1),
            ),
          ],
        );
      case SignType.danger:
        return _warning(
          Text('!',
              style: TextStyle(
                  color: AppColors.signBlack,
                  fontWeight: FontWeight.w900,
                  fontSize: size * 0.42)),
        );
      case SignType.children:
        return _warning(
          Icon(Icons.escalator_warning, color: AppColors.signBlack, size: size * 0.38),
        );
      case SignType.aheadOnly:
        return _mandatory(Icons.arrow_upward);
      case SignType.turnRight:
        return _mandatory(Icons.turn_right);
      case SignType.roundabout:
        return _mandatory(Icons.autorenew);
      case SignType.pedestrianCrossing:
        return Container(
          decoration: BoxDecoration(
            color: AppColors.signBlue,
            borderRadius: BorderRadius.circular(size * 0.1),
          ),
          padding: EdgeInsets.all(size * 0.1),
          child: CustomPaint(
            painter: _PolyPainter(
                const <Offset>[Offset(0.5, 0.02), Offset(1, 0.95), Offset(0, 0.95)],
                Colors.white,
                null,
                0),
            child: Align(
              alignment: const Alignment(0, 0.45),
              child: Icon(Icons.directions_walk, color: AppColors.signBlack, size: size * 0.4),
            ),
          ),
        );
    }
  }

  Widget _circle({required Color fill, Color? border, Widget? child}) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: fill,
        shape: BoxShape.circle,
        border: border == null ? null : Border.all(color: border, width: size * 0.1),
      ),
      child: child,
    );
  }

  Widget _prohibitory(Widget child) =>
      _circle(fill: Colors.white, border: AppColors.signRed, child: child);

  Widget _mandatory(IconData icon) => _circle(
        fill: AppColors.signBlue,
        child: Icon(icon, color: Colors.white, size: size * 0.6),
      );

  Widget _warning(Widget child) {
    return CustomPaint(
      painter: _PolyPainter(_triangleUp, Colors.white, AppColors.signRed, size * 0.09),
      child: Align(alignment: const Alignment(0, 0.4), child: child),
    );
  }
}

class _PolyPainter extends CustomPainter {
  _PolyPainter(this.points, this.fill, this.stroke, this.strokeWidth);

  final List<Offset> points;
  final Color fill;
  final Color? stroke;
  final double strokeWidth;

  @override
  void paint(Canvas canvas, Size size) {
    final Path path = Path()
      ..moveTo(points.first.dx * size.width, points.first.dy * size.height);
    for (final Offset p in points.skip(1)) {
      path.lineTo(p.dx * size.width, p.dy * size.height);
    }
    path.close();
    canvas.drawPath(path, Paint()..color = fill);
    final Color? s = stroke;
    if (s != null && strokeWidth > 0) {
      canvas.drawPath(
        path,
        Paint()
          ..color = s
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeWidth
          ..strokeJoin = StrokeJoin.round,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _PolyPainter oldDelegate) => false;
}

class _SlashPainter extends CustomPainter {
  _SlashPainter(this.color, this.width);

  final Color color;
  final double width;

  @override
  void paint(Canvas canvas, Size size) {
    final double inset = size.width * 0.17;
    canvas.drawLine(
      Offset(inset, inset),
      Offset(size.width - inset, size.height - inset),
      Paint()
        ..color = color
        ..strokeWidth = width,
    );
  }

  @override
  bool shouldRepaint(covariant _SlashPainter oldDelegate) => false;
}
