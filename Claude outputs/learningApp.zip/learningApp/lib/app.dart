import 'package:flutter/material.dart';

import 'core/app_theme.dart';
import 'screens/welcome_screen.dart';
import 'state/app_state.dart';

class AmategekoApp extends StatefulWidget {
  const AmategekoApp({super.key});

  @override
  State<AmategekoApp> createState() => _AmategekoAppState();
}

class _AmategekoAppState extends State<AmategekoApp> {
  final AppState _state = AppState();

  @override
  void dispose() {
    _state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppScope(
      notifier: _state,
      child: MaterialApp(
        title: "Amategeko y'Umuhanda",
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        home: const WelcomeScreen(),
      ),
    );
  }
}
