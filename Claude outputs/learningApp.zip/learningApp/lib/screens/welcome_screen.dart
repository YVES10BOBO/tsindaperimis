import 'package:flutter/material.dart';

import '../core/app_colors.dart';
import '../state/app_state.dart';
import 'auth_screen.dart';
import 'main_shell.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryDark,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
          child: Column(
            children: <Widget>[
              const Spacer(),
              Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: const Icon(Icons.directions_car, size: 56, color: AppColors.primary),
              ),
              const SizedBox(height: 28),
              const Text(
                "Amategeko y'Umuhanda",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              const Text(
                'Iga. Witoze. Tsinda.\nMenya amategeko, urinde ubuzima.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFC7D2FE), fontSize: 16, height: 1.5),
              ),
              const Spacer(),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: AppColors.primaryDark,
                ),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                      builder: (_) => const AuthScreen(isRegister: false)),
                ),
                child: const Text('Injira'),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white),
                ),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                      builder: (_) => const AuthScreen(isRegister: true)),
                ),
                child: const Text('Iyandikishe'),
              ),
              const SizedBox(height: 8),
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(48),
                ),
                onPressed: () {
                  AppScope.of(context).continueAsGuest();
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute<void>(builder: (_) => const MainShell()),
                  );
                },
                child: const Text('Komeza nka Mushyitsi (utiyandikishije)'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
