import 'package:flutter/material.dart';

import '../core/app_colors.dart';
import '../data/content_repository.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import '../widgets/road_sign.dart';

/// Tab y'Imyitozo: guhitamo ibibazo umuntu ashaka kwitoza.
class PracticeHomeScreen extends StatelessWidget {
  const PracticeHomeScreen({super.key});

  void _start(BuildContext context, String title, List<Question> source) {
    if (source.isEmpty) return;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => PracticeQuizScreen(
          title: title,
          questions: ContentRepository.instance.shuffledQuestions(source),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppState state = AppScope.of(context);
    final ContentRepository repo = ContentRepository.instance;
    final List<Question> wrong = <Question>[
      for (final String id in state.wrongQuestions)
        if (repo.questionById(id) != null) repo.questionById(id)!,
    ];

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: <Widget>[
          const Text('Imyitozo',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text(
            'Ikibazo kimwe kimwe. Uhita ubona niba ari cyo n\'impamvu yacyo.',
            style: TextStyle(color: AppColors.muted, fontSize: 14.5, height: 1.4),
          ),
          const SizedBox(height: 18),
          AppCard(
            color: AppColors.primary,
            borderColor: AppColors.primary,
            onTap: () => _start(context, 'Ibibazo bivanze', repo.allQuestions),
            child: Row(
              children: <Widget>[
                const IconBadge(
                    icon: Icons.shuffle, color: AppColors.primary, background: Colors.white),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Text('Ibibazo bivanze',
                          style: TextStyle(
                              color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                      Text('Ibibazo ${repo.allQuestions.length} byo mu byiciro byose',
                          style: const TextStyle(color: Color(0xFFDBEAFE), fontSize: 13)),
                    ],
                  ),
                ),
                const Icon(Icons.play_circle_fill, color: Colors.white, size: 32),
              ],
            ),
          ),
          const SizedBox(height: 12),
          AppCard(
            color: AppColors.errorSoft,
            borderColor: const Color(0xFFFBCACA),
            onTap: wrong.isEmpty
                ? () => showComingSoon(context, 'Nta kibazo wakoze nabi kugeza ubu.')
                : () => _start(context, 'Amakosa yawe', wrong),
            child: Row(
              children: <Widget>[
                const IconBadge(
                    icon: Icons.replay, color: Colors.white, background: AppColors.error),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Text('Subiramo amakosa yawe',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      Text('Ibibazo ${wrong.length} wakoze nabi',
                          style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, color: AppColors.muted),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const SectionTitle('Hitamo icyiciro'),
          const SizedBox(height: 8),
          for (final LearnCategory c in repo.categories)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                radius: 14,
                onTap: () => _start(context, c.title, repo.questionsFor(c.id)),
                child: Row(
                  children: <Widget>[
                    IconBadge(icon: c.icon, color: c.color, background: c.softColor, size: 40),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(c.title,
                              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 2),
                          Text('Ibibazo ${repo.questionsFor(c.id).length}',
                              style: const TextStyle(fontSize: 12.5, color: AppColors.muted)),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right, color: AppColors.muted),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Imyitozo: igisubizo n'impamvu bigaragara ako kanya.
class PracticeQuizScreen extends StatefulWidget {
  const PracticeQuizScreen({super.key, required this.title, required this.questions});

  final String title;
  final List<Question> questions;

  @override
  State<PracticeQuizScreen> createState() => _PracticeQuizScreenState();
}

class _PracticeQuizScreenState extends State<PracticeQuizScreen> {
  int _index = 0;
  int? _selected;
  int _correct = 0;
  bool _finished = false;

  Question get _q => widget.questions[_index];

  void _choose(int i) {
    if (_selected != null) return;
    final bool ok = i == _q.correctIndex;
    setState(() {
      _selected = i;
      if (ok) _correct++;
    });
    AppScope.of(context).recordAnswer(_q, ok);
  }

  void _next() {
    if (_index + 1 >= widget.questions.length) {
      setState(() => _finished = true);
      return;
    }
    setState(() {
      _index++;
      _selected = null;
    });
  }

  void _restart() {
    setState(() {
      _index = 0;
      _selected = null;
      _correct = 0;
      _finished = false;
    });
  }

  OptionState _stateFor(int i) {
    if (_selected == null) return OptionState.neutral;
    if (i == _q.correctIndex) return OptionState.correct;
    if (i == _selected) return OptionState.wrong;
    return OptionState.dimmed;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: const EmptyState(
          icon: Icons.quiz_outlined,
          title: 'Nta bibazo bihari',
          message: 'Ibibazo by\'iki cyiciro bizongerwamo vuba.',
        ),
      );
    }
    if (_finished) return _buildSummary();

    final AppState state = AppScope.of(context);
    final int total = widget.questions.length;
    final bool answered = _selected != null;
    final bool isRight = answered && _selected == _q.correctIndex;
    final bool bookmarked = state.isQuestionBookmarked(_q.id);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(fontSize: 17)),
        actions: <Widget>[
          IconButton(
            tooltip: 'Umva ikibazo',
            icon: const Icon(Icons.volume_up_outlined),
            onPressed: () => showComingSoon(context, 'Amajwi azongerwamo vuba.'),
          ),
          IconButton(
            tooltip: 'Bika ikibazo',
            icon: Icon(bookmarked ? Icons.bookmark : Icons.bookmark_border,
                color: bookmarked ? AppColors.primary : null),
            onPressed: () => state.toggleQuestionBookmark(_q.id),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Text('Ikibazo ${_index + 1} kuri $total',
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      const Spacer(),
                      Text('Wakoze neza: $_correct',
                          style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w600)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  AppProgressBar(value: (_index + 1) / total),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                children: <Widget>[
                  if (_q.sign != null) ...<Widget>[
                    AppCard(
                      child: Center(
                          child: RoadSign(type: _q.sign!, size: 120, label: _q.signLabel)),
                    ),
                    const SizedBox(height: 16),
                  ],
                  Text(_q.text,
                      style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700, height: 1.4)),
                  const SizedBox(height: 16),
                  for (int i = 0; i < _q.options.length; i++)
                    OptionTile(
                      letter: optionLetter(i),
                      text: _q.options[i],
                      state: _stateFor(i),
                      onTap: answered ? null : () => _choose(i),
                    ),
                  if (answered) ...<Widget>[
                    const SizedBox(height: 6),
                    AppCard(
                      color: isRight ? AppColors.successSoft : AppColors.errorSoft,
                      borderColor: isRight ? const Color(0xFFBBF7D0) : const Color(0xFFFBCACA),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            isRight
                                ? 'Ni byo!'
                                : 'Si byo. Igisubizo nyacyo ni ${optionLetter(_q.correctIndex)}.',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              color: isRight ? const Color(0xFF14532D) : const Color(0xFF7F1D1D),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(_q.explanation,
                              style: const TextStyle(height: 1.5, color: Color(0xFF374151))),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: ElevatedButton(
                onPressed: answered ? _next : null,
                child: Text(!answered
                    ? 'Hitamo igisubizo'
                    : (_index + 1 >= total ? 'Reba uko wakoze' : 'Ikibazo gikurikira')),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummary() {
    final int total = widget.questions.length;
    final double ratio = _correct / total;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: <Widget>[
              const Spacer(),
              ProgressRing(
                value: ratio,
                size: 150,
                stroke: 12,
                fontSize: 30,
                color: ratio >= 0.6 ? AppColors.success : AppColors.warning,
                label: '$_correct/$total',
              ),
              const SizedBox(height: 20),
              Text(ratio >= 0.6 ? 'Wakoze neza!' : 'Komeza witoze!',
                  style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text('Wasubije neza ibibazo $_correct kuri $total.',
                  style: const TextStyle(color: AppColors.muted, fontSize: 15)),
              const Spacer(),
              ElevatedButton(onPressed: _restart, child: const Text('Ongera witoze')),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Subira inyuma'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
