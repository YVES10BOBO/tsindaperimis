import 'package:flutter/material.dart';

import '../core/app_colors.dart';
import '../data/content_repository.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'auth_screen.dart';
import 'lesson_screen.dart';
import 'welcome_screen.dart';

// =====================================================================
// Ibindi (konti, ibyabitswe, premium, igenamiterere)
// =====================================================================
class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  void _push(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  Future<void> _chooseLanguage(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: Colors.white,
      builder: (BuildContext ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const ListTile(
              leading: Icon(Icons.check_circle, color: AppColors.primary),
              title: Text('Ikinyarwanda'),
            ),
            ListTile(
              leading: const Icon(Icons.radio_button_unchecked),
              title: const Text('English'),
              subtitle: const Text('Izaza vuba'),
              onTap: () => Navigator.pop(ctx),
            ),
            const ListTile(
              leading: Icon(Icons.radio_button_unchecked),
              title: Text('Français'),
              subtitle: Text('Izaza vuba'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppState state = AppScope.of(context);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: <Widget>[
          const Text('Ibindi', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          AppCard(
            child: Row(
              children: <Widget>[
                CircleAvatar(
                  radius: 28,
                  backgroundColor: AppColors.primarySoft,
                  child: Text(
                    state.displayName.substring(0, 1).toUpperCase(),
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.primary),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(state.displayName,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(
                        state.isGuest
                            ? 'Mushyitsi · iterambere ntiribikwa'
                            : (state.isPremium ? 'Konti ya Premium' : 'Konti isanzwe'),
                        style: const TextStyle(color: AppColors.muted, fontSize: 13),
                      ),
                    ],
                  ),
                ),
                if (state.isGuest)
                  TextButton(
                    onPressed: () => _push(context, const AuthScreen(isRegister: true)),
                    child: const Text('Iyandikishe'),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          if (!state.isPremium)
            AppCard(
              color: AppColors.primaryDark,
              borderColor: AppColors.primaryDark,
              onTap: () => _push(context, const PremiumScreen()),
              child: const Row(
                children: <Widget>[
                  Icon(Icons.workspace_premium, color: Color(0xFFFACC15), size: 32),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text('Fungura Premium',
                            style: TextStyle(
                                color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                        SizedBox(height: 2),
                        Text('Ibizamini byose, ibibazo byinshi, nta matangazo',
                            style: TextStyle(color: Color(0xFFC7D2FE), fontSize: 13)),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right, color: Colors.white),
                ],
              ),
            ),
          const SizedBox(height: 14),
          AppCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: <Widget>[
                _MenuTile(
                  icon: Icons.bookmark_outline,
                  title: 'Ibyo nabitse',
                  onTap: () => _push(context, const BookmarksScreen()),
                ),
                _MenuTile(
                  icon: Icons.notifications_none,
                  title: 'Ubutumwa',
                  onTap: () => _push(context, const NotificationsScreen()),
                ),
                _MenuTile(
                  icon: Icons.language,
                  title: 'Ururimi',
                  trailingText: 'Ikinyarwanda',
                  onTap: () => _chooseLanguage(context),
                ),
                SwitchListTile(
                  secondary: const Icon(Icons.alarm, color: AppColors.text),
                  title: const Text('Unyibutse kwiga buri munsi'),
                  value: state.notificationsOn,
                  onChanged: state.setNotifications,
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          AppCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: <Widget>[
                _MenuTile(
                  icon: Icons.help_outline,
                  title: 'Ubufasha',
                  onTap: () => showComingSoon(context, 'Ubufasha buzongerwamo vuba.'),
                ),
                _MenuTile(
                  icon: Icons.info_outline,
                  title: 'Ibyerekeye app',
                  onTap: () => showAboutDialog(
                    context: context,
                    applicationName: "Amategeko y'Umuhanda",
                    applicationVersion: '0.1.0',
                    children: const <Widget>[
                      Text('App yo kwiga amategeko y\'umuhanda no kwitegura ikizamini cy\'uruhushya rwo gutwara. '
                          'Ibirimo bigomba kugenzurwa n\'amabwiriza agezweho ya Polisi y\'u Rwanda.'),
                    ],
                  ),
                ),
                if (!state.isGuest)
                  _MenuTile(
                    icon: Icons.logout,
                    title: 'Sohoka',
                    color: AppColors.error,
                    onTap: () {
                      state.signOut();
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute<void>(builder: (_) => const WelcomeScreen()),
                        (Route<dynamic> r) => false,
                      );
                    },
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.trailingText,
    this.color = AppColors.text,
  });

  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final String? trailingText;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (trailingText != null)
            Text(trailingText!, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          const Icon(Icons.chevron_right, color: AppColors.muted),
        ],
      ),
      onTap: onTap,
    );
  }
}

// =====================================================================
// Ibyo nabitse
// =====================================================================
class BookmarksScreen extends StatelessWidget {
  const BookmarksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppState state = AppScope.of(context);
    final ContentRepository repo = ContentRepository.instance;
    final List<Lesson> lessons = <Lesson>[
      for (final String id in state.bookmarkedLessons)
        if (repo.lessonById(id) != null) repo.lessonById(id)!,
    ];
    final List<Question> questions = <Question>[
      for (final String id in state.bookmarkedQuestions)
        if (repo.questionById(id) != null) repo.questionById(id)!,
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Ibyo nabitse')),
      body: (lessons.isEmpty && questions.isEmpty)
          ? const EmptyState(
              icon: Icons.bookmark_border,
              title: 'Nta kintu urabika',
              message: 'Kanda ikimenyetso cyo kubika ku isomo cyangwa ku kibazo kugira ngo kize hano.',
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              children: <Widget>[
                if (lessons.isNotEmpty) ...<Widget>[
                  const SectionTitle('Amasomo'),
                  const SizedBox(height: 6),
                  for (final Lesson l in lessons)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: AppCard(
                        radius: 14,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(builder: (_) => LessonScreen(lesson: l)),
                        ),
                        child: Row(
                          children: <Widget>[
                            const Icon(Icons.article_outlined, color: AppColors.primary),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(l.title,
                                  style: const TextStyle(fontWeight: FontWeight.w600)),
                            ),
                            const Icon(Icons.chevron_right, color: AppColors.muted),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                ],
                if (questions.isNotEmpty) ...<Widget>[
                  const SectionTitle('Ibibazo'),
                  const SizedBox(height: 6),
                  for (final Question q in questions)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: AppCard(
                        radius: 14,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Expanded(
                                  child: Text(q.text,
                                      style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4)),
                                ),
                                IconButton(
                                  tooltip: 'Kuramo',
                                  icon: const Icon(Icons.bookmark, color: AppColors.primary),
                                  onPressed: () => state.toggleQuestionBookmark(q.id),
                                ),
                              ],
                            ),
                            Text('Igisubizo: ${q.correctAnswer}',
                                style: const TextStyle(
                                    color: AppColors.success, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    ),
                ],
              ],
            ),
    );
  }
}

// =====================================================================
// Ubutumwa
// =====================================================================
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<AppNotification> items = ContentRepository.instance.notifications;
    return Scaffold(
      appBar: AppBar(title: const Text('Ubutumwa')),
      body: ListView.separated(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (BuildContext context, int i) {
          final AppNotification n = items[i];
          return AppCard(
            radius: 14,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                IconBadge(
                    icon: n.icon, color: AppColors.primary, background: AppColors.primarySoft, size: 40),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(n.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 2),
                      Text(n.body, style: const TextStyle(color: AppColors.muted, height: 1.4)),
                      const SizedBox(height: 4),
                      Text(n.when, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// =====================================================================
// Premium (kwishyura na MoMo / Airtel Money) — UI gusa
// =====================================================================
class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  String _method = 'mtn';
  final TextEditingController _phone = TextEditingController();

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  void _pay() {
    final String digits = _phone.text.replaceAll(RegExp(r'\D'), '');
    if (digits.length < 10) {
      showComingSoon(context, 'Andika nimero ya telefoni yuzuye.');
      return;
    }
    // TODO: Hamagara backend (Payments module) ihuza na MTN MoMo / Airtel Money API.
    AppScope.of(context).activatePremium();
    showComingSoon(context, 'Igerageza: Premium yafunguwe. Kwishyura nyabyo bizahuzwa na backend.');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Premium')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: <Widget>[
          const Center(
            child: Icon(Icons.workspace_premium, size: 64, color: Color(0xFFEAB308)),
          ),
          const SizedBox(height: 10),
          const Text('Fungura Premium',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('[IGICIRO] RWF / ukwezi',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.muted, fontSize: 15)),
          const SizedBox(height: 18),
          const AppCard(
            child: Column(
              children: <Widget>[
                _Perk('Ibizamini by\'igerageza bitagira umubare'),
                _Perk('Ibibazo byose n\'ibisobanuro byabyo'),
                _Perk('Amasomo yose akora nta interineti'),
                _Perk('Nta matangazo'),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('Uburyo bwo kwishyura',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 10),
          _PayMethod(
            label: 'MTN Mobile Money',
            color: const Color(0xFFFFCC00),
            selected: _method == 'mtn',
            onTap: () => setState(() => _method = 'mtn'),
          ),
          const SizedBox(height: 10),
          _PayMethod(
            label: 'Airtel Money',
            color: const Color(0xFFE40000),
            selected: _method == 'airtel',
            onTap: () => setState(() => _method = 'airtel'),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Nimero ya telefoni',
              hintText: '07X XXX XXXX',
              prefixIcon: Icon(Icons.phone_outlined),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: _pay, child: const Text('Ishyura')),
          const SizedBox(height: 10),
          const Text(
            'Uzakira ubutumwa kuri telefoni bwo kwemeza kwishyura.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.muted, fontSize: 12.5),
          ),
        ],
      ),
    );
  }
}

class _Perk extends StatelessWidget {
  const _Perk(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: <Widget>[
          const Icon(Icons.check_circle, color: AppColors.success, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}

class _PayMethod extends StatelessWidget {
  const _PayMethod({
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      radius: 14,
      color: selected ? AppColors.primarySoft : AppColors.surface,
      borderColor: selected ? AppColors.primary : AppColors.border,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: <Widget>[
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.phone_android, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700))),
          Icon(selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
              color: selected ? AppColors.primary : AppColors.muted),
        ],
      ),
    );
  }
}
