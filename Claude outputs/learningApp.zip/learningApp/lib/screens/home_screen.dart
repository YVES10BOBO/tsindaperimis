import 'package:flutter/material.dart';

import '../core/app_colors.dart';
import '../data/content_repository.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'auth_screen.dart';
import 'category_screen.dart';
import 'more_screen.dart';
import 'search_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.onOpenTab});

  final ValueChanged<int> onOpenTab;

  @override
  Widget build(BuildContext context) {
    final AppState state = AppScope.of(context);
    final ContentRepository repo = ContentRepository.instance;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: <Widget>[
          // ---------- Header ----------
          Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Muraho, ${state.displayName}',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    const Text('Komeza wige, witegure utsinde!',
                        style: TextStyle(color: AppColors.muted, fontSize: 14)),
                  ],
                ),
              ),
              IconButton.outlined(
                tooltip: 'Ubutumwa',
                style: IconButton.styleFrom(
                  side: const BorderSide(color: AppColors.border),
                  backgroundColor: Colors.white,
                ),
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const NotificationsScreen()),
                ),
                icon: const Icon(Icons.notifications_none),
              ),
            ],
          ),
          const SizedBox(height: 18),

          // ---------- Progress ----------
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text('Iterambere ryawe',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                const SizedBox(height: 14),
                Row(
                  children: <Widget>[
                    ProgressRing(value: state.readiness, size: 88, stroke: 9),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        children: <Widget>[
                          _StatRow('Amasomo warangije',
                              '${state.completedLessons.length} / ${repo.totalLessons}'),
                          _StatRow('Ibibazo wakoze', '${state.totalAnswered}'),
                          _StatRow('Ibizamini wakoze', '${state.examResults.length}'),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 42,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(minimumSize: const Size(0, 42)),
                    onPressed: () => onOpenTab(3),
                    child: const Text('Reba iterambere', style: TextStyle(fontSize: 14)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // ---------- Search ----------
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            radius: 14,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SearchScreen()),
            ),
            child: const Row(
              children: <Widget>[
                Icon(Icons.search, color: AppColors.muted),
                SizedBox(width: 10),
                Text('Shakisha amategeko, ibimenyetso...',
                    style: TextStyle(color: AppColors.muted, fontSize: 15)),
              ],
            ),
          ),

          if (state.isGuest) ...<Widget>[
            const SizedBox(height: 16),
            AppCard(
              color: AppColors.warningSoft,
              borderColor: const Color(0xFFFDE2B3),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const AuthScreen(isRegister: true)),
              ),
              child: const Row(
                children: <Widget>[
                  Icon(Icons.info_outline, color: Color(0xFFB45309)),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Uri gukoresha app nka Mushyitsi. Iyandikishe kugira ngo iterambere ryawe ribikwe.',
                      style: TextStyle(color: Color(0xFF78350F), height: 1.4),
                    ),
                  ),
                  Icon(Icons.chevron_right, color: Color(0xFFB45309)),
                ],
              ),
            ),
          ],
          const SizedBox(height: 22),

          // ---------- Categories ----------
          const SectionTitle('Ibyiciro byo kwiga'),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.92,
            children: <Widget>[
              for (final LearnCategory c in repo.categories)
                CategoryTile(
                  category: c,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => CategoryScreen(category: c)),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 22),

          // ---------- Quick actions ----------
          const SectionTitle('Witoze kandi wipime'),
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              Expanded(
                child: _QuickAction(
                  icon: Icons.edit_note,
                  color: AppColors.success,
                  soft: AppColors.successSoft,
                  title: 'Imyitozo',
                  subtitle: 'Ikibazo kimwe kimwe, igisubizo ako kanya',
                  onTap: () => onOpenTab(1),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _QuickAction(
                  icon: Icons.assignment,
                  color: AppColors.purple,
                  soft: AppColors.purpleSoft,
                  title: 'Ikizamini',
                  subtitle: 'Ikizamini cy\'igerageza gifite igihe',
                  onTap: () => onOpenTab(2),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  const _StatRow(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text(label,
                style: const TextStyle(color: AppColors.muted, fontSize: 13.5)),
          ),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({
    required this.icon,
    required this.color,
    required this.soft,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final Color color;
  final Color soft;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      color: soft,
      borderColor: color.withAlpha(50),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          IconBadge(icon: icon, color: Colors.white, background: color, size: 40),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(subtitle,
              style: const TextStyle(fontSize: 12.5, color: AppColors.muted, height: 1.35)),
        ],
      ),
    );
  }
}
