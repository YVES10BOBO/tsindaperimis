import 'package:flutter/widgets.dart';

import '../data/content_repository.dart';
import '../data/models.dart';

/// Imiterere ya app (umukoresha, iterambere, ibyo yabitse).
/// Ubu ibikwa muri memory; intambwe ikurikira ni kubibika muri SQLite.
class AppState extends ChangeNotifier {
  String? _userName;
  bool _isGuest = true;
  bool notificationsOn = true;
  bool isPremium = false;

  final Set<String> completedLessons = <String>{};
  final Set<String> bookmarkedLessons = <String>{};
  final Set<String> bookmarkedQuestions = <String>{};
  final Set<String> wrongQuestions = <String>{};
  final Map<String, int> answeredByCategory = <String, int>{};
  final Map<String, int> correctByCategory = <String, int>{};
  final List<ExamResult> examResults = <ExamResult>[];

  bool get isGuest => _isGuest;
  String get displayName => _userName ?? 'Mushyitsi';

  // ---------- Konti ----------
  void signIn(String name) {
    _userName = name.trim().isEmpty ? 'Umukoresha' : name.trim();
    _isGuest = false;
    notifyListeners();
  }

  void continueAsGuest() {
    _userName = null;
    _isGuest = true;
    notifyListeners();
  }

  void signOut() => continueAsGuest();

  void setNotifications(bool value) {
    notificationsOn = value;
    notifyListeners();
  }

  void activatePremium() {
    isPremium = true;
    notifyListeners();
  }

  // ---------- Amasomo ----------
  bool isLessonDone(String id) => completedLessons.contains(id);

  void completeLesson(String id) {
    completedLessons.add(id);
    notifyListeners();
  }

  int completedIn(LearnCategory c) =>
      c.lessons.where((Lesson l) => completedLessons.contains(l.id)).length;

  // ---------- Ibyabitswe ----------
  bool isLessonBookmarked(String id) => bookmarkedLessons.contains(id);
  bool isQuestionBookmarked(String id) => bookmarkedQuestions.contains(id);

  void toggleLessonBookmark(String id) {
    if (!bookmarkedLessons.remove(id)) bookmarkedLessons.add(id);
    notifyListeners();
  }

  void toggleQuestionBookmark(String id) {
    if (!bookmarkedQuestions.remove(id)) bookmarkedQuestions.add(id);
    notifyListeners();
  }

  // ---------- Ibisubizo ----------
  void recordAnswer(Question q, bool correct, {bool notify = true}) {
    answeredByCategory[q.categoryId] = (answeredByCategory[q.categoryId] ?? 0) + 1;
    if (correct) {
      correctByCategory[q.categoryId] = (correctByCategory[q.categoryId] ?? 0) + 1;
      wrongQuestions.remove(q.id);
    } else {
      wrongQuestions.add(q.id);
    }
    if (notify) notifyListeners();
  }

  void addExamResult(ExamResult result) {
    for (int i = 0; i < result.questions.length; i++) {
      if (result.answers[i] != null) {
        recordAnswer(result.questions[i], result.isCorrect(i), notify: false);
      }
    }
    examResults.insert(0, result);
    notifyListeners();
  }

  int get totalAnswered =>
      answeredByCategory.values.fold(0, (int a, int b) => a + b);

  int get totalCorrect =>
      correctByCategory.values.fold(0, (int a, int b) => a + b);

  double get accuracy => totalAnswered == 0 ? 0 : totalCorrect / totalAnswered;

  double categoryAccuracy(String id) {
    final int answered = answeredByCategory[id] ?? 0;
    if (answered == 0) return 0;
    return (correctByCategory[id] ?? 0) / answered;
  }

  double get averageExamRatio {
    if (examResults.isEmpty) return 0;
    final double sum =
        examResults.fold(0.0, (double a, ExamResult r) => a + r.ratio);
    return sum / examResults.length;
  }

  /// Ijanisha ry'uko umuntu yiteguye: amasomo 40%, imyitozo 30%, ibizamini 30%.
  double get readiness {
    final int total = ContentRepository.instance.totalLessons;
    final double lessons = total == 0 ? 0 : completedLessons.length / total;
    final double exam = examResults.isEmpty ? 0 : examResults.first.ratio;
    return (lessons * 0.4 + accuracy * 0.3 + exam * 0.3).clamp(0.0, 1.0).toDouble();
  }
}

class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required super.notifier, required super.child});

  static AppState of(BuildContext context) {
    final AppScope? scope =
        context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope ntiboneka');
    return scope!.notifier!;
  }
}
