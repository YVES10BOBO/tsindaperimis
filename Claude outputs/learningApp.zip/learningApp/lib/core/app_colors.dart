import 'package:flutter/material.dart';

/// Amabara ya app (akurikiza design: umweru, ubururu, n'amabara yoroheje ku byiciro).
class AppColors {
  AppColors._();

  static const Color primary = Color(0xFF2563EB);
  static const Color primaryDark = Color(0xFF1E3A8A);
  static const Color primarySoft = Color(0xFFEAF1FF);

  static const Color background = Color(0xFFF7F9FC);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color border = Color(0xFFE5E9F0);

  static const Color text = Color(0xFF111827);
  static const Color muted = Color(0xFF6B7280);

  static const Color success = Color(0xFF16A34A);
  static const Color successSoft = Color(0xFFEAF8EE);
  static const Color error = Color(0xFFDC2626);
  static const Color errorSoft = Color(0xFFFDECEC);
  static const Color warning = Color(0xFFF59E0B);
  static const Color warningSoft = Color(0xFFFFF4E0);
  static const Color purple = Color(0xFF7C3AED);
  static const Color purpleSoft = Color(0xFFF1EBFF);

  static const Color signRed = Color(0xFFD32F2F);
  static const Color signBlue = Color(0xFF1565C0);
  static const Color signBlack = Color(0xFF111111);
}
